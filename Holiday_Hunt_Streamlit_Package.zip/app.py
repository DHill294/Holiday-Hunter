import streamlit as st
from datetime import date, datetime

st.set_page_config(page_title="Holiday Hunt", page_icon="🏖️", layout="wide", initial_sidebar_state="collapsed")

if "package_alerts" not in st.session_state:
    st.session_state.package_alerts = []
if "flight_alerts" not in st.session_state:
    st.session_state.flight_alerts = []
if "package_results" not in st.session_state:
    st.session_state.package_results = []
if "flight_results" not in st.session_state:
    st.session_state.flight_results = []
if "package_matches" not in st.session_state:
    st.session_state.package_matches = []

st.markdown(
    """
    <style>
    :root {
      --bg: #07152a;
      --panel: #0d2240;
      --panel-2: #123058;
      --text: #ffffff;
      --muted: #c9d7ef;
      --accent: #78a9ff;
      --accent-2: #3f7af7;
      --border: rgba(255,255,255,0.12);
    }
    .stApp {
      background: radial-gradient(circle at top left, #0c2142 0%, #07152a 55%, #05101f 100%);
      color: var(--text);
    }
    html, body, [class*="css"]  { color: var(--text); }
    .block-container { padding-top: 1.2rem; padding-bottom: 2rem; max-width: 1200px; }
    h1, h2, h3, h4, p, label, div, span { color: var(--text) !important; }
    .hero {
      background: linear-gradient(180deg, rgba(18,48,88,.95), rgba(13,34,64,.9));
      border: 1px solid var(--border); border-radius: 24px; padding: 1.2rem; margin-bottom: 1rem;
      box-shadow: 0 10px 30px rgba(0,0,0,.18);
    }
    .hero p { color: var(--muted) !important; margin-bottom: 0; }
    .panel {
      background: linear-gradient(180deg, rgba(18,48,88,.92), rgba(13,34,64,.88));
      border: 1px solid var(--border); border-radius: 22px; padding: 1rem; box-shadow: 0 8px 24px rgba(0,0,0,.16);
    }
    .metric-card {
      background: rgba(255,255,255,0.05); border: 1px solid var(--border); border-radius: 18px; padding: .9rem 1rem; margin-bottom: .6rem;
    }
    .small-muted { color: var(--muted) !important; font-size: 0.92rem; }
    .stTabs [data-baseweb="tab-list"] { gap: 8px; background: rgba(255,255,255,0.04); padding: 8px; border-radius: 18px; border: 1px solid var(--border); }
    .stTabs [data-baseweb="tab"] { height: 44px; border-radius: 14px; background: rgba(255,255,255,0.03); color: var(--muted); padding-left: 16px; padding-right: 16px; }
    .stTabs [aria-selected="true"] { background: linear-gradient(180deg, var(--accent), var(--accent-2)); color: white; }
    .stTextInput input, .stNumberInput input, .stSelectbox div, .stMultiSelect div, .stDateInput input, .stTextArea textarea {
      background: rgba(255,255,255,0.06) !important; color: white !important; border: 1px solid var(--border) !important; border-radius: 14px !important;
    }
    .stButton button { background: linear-gradient(180deg, var(--accent), var(--accent-2)) !important; color: white !important; border: none !important; border-radius: 14px !important; font-weight: 700 !important; }
    .stButton button:hover { filter: brightness(1.08); }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown('<div class="hero"><h1>Holiday Hunt</h1><p>Search package holidays and flights, save alerts, and keep the app bookmarkable on your phone.</p><p><a href="https://www.tui.co.uk/destinations/holidays" target="_blank" style="color:#cfe3ff;">TUI search</a> · <a href="https://www.onthebeach.co.uk/results?adults=2&children=0&nights=7" target="_blank" style="color:#cfe3ff;">On the Beach search</a></p></div>', unsafe_allow_html=True)

tab1, tab2 = st.tabs(["Package holidays", "Flights"])

with tab1:
    col1, col2 = st.columns([2, 1], gap="large")
    with col1:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Package holiday search")
        st.caption("Live package matches will pull from TUI and On the Beach, with direct listing links where available.")
        with st.form("package_form", clear_on_submit=False):
            destination = st.text_input("Destination", placeholder="Mallorca, Crete, Algarve")
            provider = st.selectbox("Provider", ["Any", "TUI", "On the Beach", "Lastminute.com"])
            d1, d2 = st.columns(2)
            with d1:
                depart = st.date_input("Departure date", value=date.today())
                airports = st.multiselect("Departure airports", ["LGW", "LHR", "LTN", "STN", "MAN", "BHX"], default=["LGW", "MAN"])
                board = st.selectbox("Board basis", ["Any", "Room only", "Self catering", "Breakfast", "Half board", "All inclusive"])
            with d2:
                return_date = st.date_input("Return date", value=date.today())
                nights = st.number_input("Nights", min_value=3, max_value=21, value=7)
                budget = st.number_input("Max budget (£)", min_value=100, value=500, step=10)
            d3, d4 = st.columns(2)
            with d3:
                tripadvisor = st.selectbox("TripAdvisor score min", ["Any", "7+", "8+", "8.5+", "9+"])
                rating = st.selectbox("Hotel rating min", ["Any", "3★+", "4★+", "5★"])
            with d4:
                beach_distance = st.selectbox("Max beach distance", ["Any", "0.5 km", "1 km", "2 km", "5 km"])
                flexibility = st.selectbox("Date flexibility", ["Exact dates", "Within 1 day", "Within 2 days"])
            amenities = st.multiselect("Amenities", ["Wi‑Fi", "Pool", "Air conditioning", "Parking", "Spa", "Family friendly", "Kitchenette", "Beachfront"])
            channels = st.multiselect("Notification channels", ["In-app", "Email", "Browser push"], default=["In-app", "Email"])
            save = st.form_submit_button("Save search alert")
        if st.button("Refresh demo match link"):
            st.session_state.package_matches.insert(0, {"title": f"{destination or "Sample deal"}", "price": budget, "link": "https://www.onthebeach.co.uk/holidays", "provider": provider, "captured_at": datetime.now().strftime("%Y-%m-%d %H:%M")})
            st.success("Demo match refreshed")
        st.markdown('</div>', unsafe_allow_html=True)
        if save and destination:
            st.session_state.package_alerts.insert(0, {
                "destination": destination, "provider": provider, "depart": depart, "return_date": return_date,
                "airports": airports, "board": board, "nights": nights, "budget": budget,
                "tripadvisor": tripadvisor, "rating": rating, "beach_distance": beach_distance,
                "flexibility": flexibility, "amenities": amenities, "channels": channels, "created_at": datetime.now().strftime('%Y-%m-%d %H:%M')
            })
            st.success("Package alert saved")

    with col2:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Live package matches")
        if not st.session_state.package_results:
            st.markdown('<div class="metric-card"><span class="small-muted">No live package matches yet.</span></div>', unsafe_allow_html=True)
        for match in st.session_state.package_results[:5]:
            with st.container(border=True):
                st.write(f"**{match['title']}** · {match['provider']}")
                st.caption(f"{match['destination']} · {match['airport']} · {match['depart_date']} to {match['return_date']} · £{match['price']}")
                st.markdown(f"[Open listing]({match['link']})")

        st.subheader("Package alerts")
        if not st.session_state.package_alerts:
            st.markdown('<div class="metric-card"><span class="small-muted">No package alerts yet.</span></div>', unsafe_allow_html=True)
        if st.session_state.package_results:
            st.markdown("**Recent match**")
            st.write(st.session_state.package_results[0].get("title", "Match"))
            st.markdown(f"[Open listing]({st.session_state.package_results[0].get("link", "#")})")
        for idx, alert in enumerate(st.session_state.package_alerts):
            with st.container(border=True):
                st.write(f"**{alert['destination']}** · {alert['provider']}")
                st.caption(f"{alert['depart']} to {alert['return_date']} · airports: {', '.join(alert['airports'])} · {alert['board']}")
                if idx < len(st.session_state.package_matches):
                    match = st.session_state.package_matches[idx]
                    st.markdown(f"[Open listing]({match['link']})")
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("Edit", key=f"edit_pkg_{idx}"):
                        st.session_state.pkg_edit = idx
                with c2:
                    if st.button("Delete", key=f"del_pkg_{idx}"):
                        st.session_state.package_alerts.pop(idx)
                        st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)

with tab2:
    col1, col2 = st.columns([2, 1], gap="large")
    with col1:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Flight search")
        with st.form("flight_form", clear_on_submit=False):
            origin = st.text_input("Origin airport", placeholder="LGW, MAN, BHX")
            destination_f = st.text_input("Destination", placeholder="Palma, Malaga, Faro")
            f1, f2 = st.columns(2)
            with f1:
                depart_f = st.date_input("Departure date", key="flight_depart", value=date.today())
                budget_f = st.number_input("Max flight price (£)", min_value=50, value=250, step=10)
            with f2:
                return_f = st.date_input("Return date", key="flight_return", value=date.today())
                cabin = st.selectbox("Cabin", ["Any", "Economy", "Premium economy", "Business"])
            flight_save = st.form_submit_button("Save flight alert")
        st.markdown('</div>', unsafe_allow_html=True)
        if flight_save and origin and destination_f:
            st.session_state.flight_alerts.insert(0, {
                "origin": origin, "destination": destination_f, "depart": depart_f, "return_date": return_f,
                "budget": budget_f, "cabin": cabin, "created_at": datetime.now().strftime('%Y-%m-%d %H:%M')
            })
            st.success("Flight alert saved")
    with col2:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Flight alerts")
        if not st.session_state.flight_alerts:
            st.markdown('<div class="metric-card"><span class="small-muted">No flight alerts yet.</span></div>', unsafe_allow_html=True)
        for idx, alert in enumerate(st.session_state.flight_alerts):
            with st.container(border=True):
                st.write(f"**{alert['origin']} → {alert['destination']}**")
                st.caption(f"{alert['depart']} to {alert['return_date']} · {alert['cabin']} · under £{alert['budget']}")
                if st.button("Delete", key=f"del_flt_{idx}"):
                    st.session_state.flight_alerts.pop(idx)
                    st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)

st.caption('Holiday Hunt is styled as a dark blue mobile-friendly Streamlit app with white text, ready to bookmark to your phone screen.')
