# Holiday Hunt

Streamlit app for package holiday and flight alerts.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```
